<!DOCTYPE html>
<html>
<head>
	<title>ADMIN</title>
</head>
<body>
<H1>ADMIN</H1>
<a href="iya.php">home</a>
<a href="view.php">Data</a>

</body>
</html>