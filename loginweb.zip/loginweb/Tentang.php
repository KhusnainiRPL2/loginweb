<!DOCTYPE html>
<html>
 <head>
  <meta charset="utf-8">
   <title>WEB DESA</title>
    <style media="screen"
     *{padding:0;margin:0
     }
      html , body{
      font-family: arial;
      background-color: rgba(0, 0,0 ,0.4);
      }
 .container {
 width: 1200px;
 margin: auto;
 background-color: cyan;
 border: 5px solid black;
}

.header {
 padding: 20px;
}

.header.judul {
 font-size: 50px;
 font-weight: bold;
 font-family: calibri;
 color: black;
 text-align: center;
padding-bottom: 10px;
padding-top: 10px;
}

.header >ul >li {
 display: inline-block;
 margin-top: 20px;
 margin-right: 10px;
}
.header a {
 font-size: 30px;
 text-decoration: none;
 border-radius: 10px;
 padding: 3px;
 text-align: center;
}
.header a:hover {
 background-color: black;
 color: white;
}
.hero {
 height: 320px;
 background-color: light blue;
 background-size: 1200px;
 background-size: cover;
 background-position: 0 -1000px;
 border-bottom: 5px solid salmon;
 border-top: 5px solid magenta;
}

.content {
 height: none;
 width: none;
 border: 5px solid black;
 position: relative;
 background-color: aqua;
}
.satu {
 background-color: solid blue;
 width: 200px
 height: 600px;
 float: left;
}
.dua {
 background-color: cyan;
 width: 990px;
 height: 600px;
 top: 0px;
 right: 0px;
 position: absolute;
}

.footer {
 background-color: black;
 padding: 10px
}
.footer .copy {
 color: white;
 text-align: center;
 font-size: 15px;
 font-family: sans-serif;
} 
</style>
</head>
<body>
 <div class="header">
  <div class="container">
   <header>
   <h1><marquee width="none" height="40">Profil Desa Mandiraja Kulon</marquee><background-color: black></h1>
</header>
   </div>
   
</div>

		
		 <div class="content">
		 
		 
		 <h1>A. Data Lurah</h1>
		 <p>Lurah desa mandiraja yang pertama yaitu bapak Martatipura,beliau menjabat sebagai lurah semenjak tahun 1943 hingga tahun 1967.<br>
		 untuk pemerintahan selanjutnya bapak muslamet sebagai lurah ke-2,kemudian bapak Ma'in , ibu Rupingah.kini ketiganya sudah meninggal dunia.<br>
		 Dan kemudian dipimpin oleh bapak Sofyan mulai dari tahun 2009 hingga sekarang.<br>
		 </p>
		 <h1>B. Data Desa</h1>
		 <p>
		  <==> Nama Desa: Mandiraja Kulon <br>
		  <==> Kecamatan: Mandiraja       <br>
		  <==> Kabupaten: Banjarnegara    <br>
		  <==> Provinsi : Jawa Tengah     <br>
		  <==> Jumlah RT: 28 RT           <br>
		  <==> Jumlah RW: 4 RW            <br>
		  <==> Jumlah KK: 1.715 KK        <br>
		  <==> Jumlah Penduduk: 6.380 Orang<br>
		  <==> Mata Pencaharian: Petani, Pedagang, Wirausaha, PNS <br>
		  <==> Potensi Keunggulan: Pasar Pagi / Pasar Desa<br>
		  <==> Potensi Lain: Pasar induk,Terminal,Puskesmas,Rumah Makan<br>

		 <div class="footer">
 <div class="copy">copyright 2017. MANDIRAJA
</div>
		  </div>
		 </div>
		</body>
	</html>    