<!DOCTYPE html>
<html>
<head>
	<title>Sejarah Desa Mandiraja</title>
	<link rel="stylesheet" type="text/css" href="halaman1.css">
</head>
<body>
<h1>Sejarah Desa Mandiraja</h1>
<p>Sejarah Desa Mandiraja ada dua versi.
Yang pertama desa mandiraja adalah nama dari sebuah pohon bayam raja.
Yang kedua sejarah desa mandiraja dilihat dari struktur kerajaan mataram kuno pada zaman kolonial Belanda.
pada awalnya desa mandiraja hanya ada satu pemerintahan. 
Karena ada perpecahan akhirnya desa mandiraja dibagi menjadi dua bagian 
yaitu mandiraja kulon dan mandiraja wetan.
Lurah desa mandiraja yang pertama yaitu bapak Martatipura, 
beliau menjabat sebagai lurah semenjak tahun 1943 hingga tahun 1967.
untuk pemerintahan selanjutnya bapak muslamet sebagai lurah ke-2,
kemudian bapak Ma'in, ibu Rupingah.kini ketiganya sudah meninggal.
sekarang bapak sofyan yang menjadi lurah di desa mandiraja kulon.
</p>

</body>
</html>