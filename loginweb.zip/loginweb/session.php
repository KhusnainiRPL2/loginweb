<?php
session_start("localhost", "root", "", "akademik");
?>
<!DOCTYPE html
<html>
<body>
	
	<?php
	//set session va riables
	$_SESSION[favcolour] = "blue"
	$_SESSION[favanimal] = "horse"
	echo "session variables tersedia.";
	?>

</body>
</html>