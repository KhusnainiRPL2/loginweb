<?php 
	
	$id = $_GET['id'];
	$koneksi = mysqli_connect('localhost','root','','akademik');
	$hapus = "DELETE FROM sejarah WHERE id='$id'";
	
	$query = mysqli_query($koneksi,$hapus);

	if ($hapus) {
		echo "
			<script>
				alert('data berhasil dihapus');
				document.location.href='view.php';
			</script>
		";
	}else{
		echo "
			<script>
				alert('data gagal dihapus');
				document.location.href='view.php';
			</script>
		";
	}

 ?>