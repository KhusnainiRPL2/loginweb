<!DOCTYPE html>
<html>
<head>
	<title>Simple CRUD</title>
</head>
<body>
	<h1>View Sejarah</h1>
	<a href="admin.php">back</a>
	<table border="1" cellpadding="10">
		<tr>
			<td>Judul</td>
			<td>Deskripsi</td>
			<td>AKSI</td>
		</tr>
		<?php 
			$koneksi = mysqli_connect('localhost','root','','akademik');

			$tampil  = "SELECT * FROM sejarah";
			$query   = mysqli_query($koneksi,$tampil);
			while ($data=mysqli_fetch_assoc($query)) {
							
		 ?>
		 <tr>
		 	<td><?php echo $data['judul']; ?></td>
		 	<td><?php echo $data['isi']; ?></td>
		 	<td>
		 		<a href="update.php?id=<?php echo $data['id']; ?>">ubah</a>|
		 		<a href="hapus.php?id=<?php echo $data['id']; ?>">hapus</a>
		 	</td>
		 </tr>
		 <?php } ?>

	</table>
</body>
</html>