<?php 
	$koneksi = mysqli_connect('localhost','root','','akademik');
	$user    = $_POST['username'];
	$pass    = $_POST['password'];

	$cek     = "SELECT * FROM login WHERE username='$user' ";
	$query   = mysqli_query($koneksi,$cek);
	$cekk    = mysqli_num_rows($query);
	if ($cekk == 1) {
		echo "
			<script>
					alert('SELAMAT DATANG');
					document.location.href='iya.php';
			</script>
		";
	}else{
		echo "
			<script>
					alert('LOGIN GAGAL');
					document.location.href='index.php';
			</script>
		";
	}

 ?>