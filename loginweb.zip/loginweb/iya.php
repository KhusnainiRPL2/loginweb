<!DOCTYPE html>
<html>
<head>
	<title>MalasNgoding's Blog</title>
	<link rel="stylesheet" type="text/css" href="halaman1.css">
</head>
<body>
	
	<!-- bagian header template -->
	<header>
		<h1 class="judul">Desa Mandiraja Kulon</h1>
		<p class="deskripsi">Berbagi Informasi Tentang Desa Mandiraja Kulon.</p>
	</header>
	<!-- akhir bagian header template -->
	
	<div class="wrap">
		<!-- bagian menu		 -->
		<nav class="menu">
			<ul>
				<li>
					<a href="iya.php">Home</a>
				</li>
				<li>
					<a href="Sejarah.php">Sejarah</a>
				</li>
				<li>
					<a href="tentang.php">Tentang desa</a>
				</li>
				<li>
					<a href="admin.php">admin</a>
				</li>
				<li>
					<a href="index.php">logout</a>
				</li>
			</ul>
		</nav>
		<!-- akhir bagian menu -->
 
		<!-- bagian sidebar website -->
		<aside class="sidebar">
			<div class="widget">
				<h2>Sejarah</h2>
				<p>Selamat datang di web Desa Mandiraja Kulon.Situs ini menyediakan informasi mengenai desa Mandiraja Kulon.</p>
			</div>
			<div class="widget">
				<h2>Tentang Desa</h2>
				<p>Teman-teman bisa menjelajahi tentang desa Mandira Kulon.</p>
			</div>
		</aside>
		<!-- akhir bagian sidebar website -->
 
		<!-- bagian konten Blog -->
		<div class="blog">
			<div class="conteudo">
				<div class="post-info">
					Di Posting Oleh <b>Khusnaini</b>
				</div>
				<h1 class="judul">Deskripsi Desa</h1>
				<p>Hai Teman-Teman disini akan dijelaskan mengenai desa Mandiraja Kulon.
				<hr>
				<p>
					Desa Mandiraja Kulon adalah salah satu desa di Kecamatan Mandiraja Kabupaten Banjarnegara yang meiliki luas wilayah 177.695 ha. Desa Mandiraja Kulon dipimpin oleh bapak M. Sofyan Hani S.pt sebagai lurah yang ke- 4. Untuk batas wilayah desa mandiraja kulon yaitu:
					@ Utara berbatasan langsung dengan desa Rakit
					@ Selatan berbatasan langsung dengan desa Somawangi
					@ Timur berbatasan langsung dengan desa Kebakalan/ Mandiraja Wetan
					@ Barat berbatasan langsung dengan desa Kerttayasa.
					Desa Mndiraja Kulon memiliki 28 Rt dan 4 Rw dengan jumlah penduduk kurang lebih 6.380 jiwa. Kebanyakan penduduk desa Mandiraja Kulon Berpancaharian sebagai Petani, Pedagang, dan PNS.
					</p>				
		</div>
		<!-- akhir bagian konten Blog -->
	</div>
 
</body>
</html>