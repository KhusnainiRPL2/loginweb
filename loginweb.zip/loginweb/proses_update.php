<?php 

	$koneksi = mysqli_connect('localhost','root','','akademik');

if (isset($_POST['submit'])) {
	$id = $_GET['id'];
	$judul = $_POST['judul'];
	$isi = $_POST['isi'];

	$update ="	UPDATE sejarah SET judul='$judul', isi='$isi' WHERE id='$id'";

	$query  = mysqli_query($koneksi,$update);
if (mysqli_affected_rows($koneksi)) {
		echo "
			<script>
				alert('data berhasil diedit');
				document.location.href='view.php';
			</script>
		";
	}else{
		echo "
			<script>
				alert('data gagal diedit');
				document.location.href='update.php';
			</script>
		";
	}
	
	}

	
 ?>