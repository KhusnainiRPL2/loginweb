<?php
include('koneksi2.php');
$tampil=mysqli_query($koneksi2, "SELECT * FROM profil WHERE no_profil='$no'");
$out=mysqli_fetch_array($tampil);
?>
<div class="content-wrapper">
<section class="content">
<form action="update_profil.php" method="POST">
	<input type="hidden" name="no" value="<?php echo $no; ?>" />
	judul	: <input type="text" name="judul_profil" value="<?php echo $out['judul_profil']; ?>"> <br/> <br/>
	isi	: <textarea name="isi_profil"><?php echo $out['isi_profil']; ?></textarea>
	<input type="submit" value="Simpan Perubahan">
</form>
</div>
</section>