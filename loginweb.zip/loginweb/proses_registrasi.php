<?php 
	$koneksi = mysqli_connect('localhost','root','','akademik');
	if (isset($_POST['submit'])) {

	$user    = $_POST['username'];
	$pass    = $_POST['password'];

	$cek     = "INSERT INTO login VALUES('$user', '$pass','')";
	$query   = mysqli_query($koneksi,$cek);
	if ($cek) {
		echo "
			<script>
					alert('SELAMAT DATANG');
					document.location.href='index.php';
			</script>
		";
	}else{
		echo "
			<script>
					alert('REGISTRASI GAGAL');
					document.location.href='registrasi.php';
			</script>
		";
	}

	}
 ?>