 <!DOCTYPE html>
<html>
<head>
	<title>UPDATE DATA</title>
</head>
<body>
	<h2>UPDATE</h2>
	<br/><?php 
		$id= $_GET['id'];
		$koneksi = mysqli_connect('localhost','root','','akademik');
		$tampil  = "SELECT * FROM sejarah WHERE id='$id'";
		$query   = mysqli_query($koneksi,$tampil);
		while ($data = mysqli_fetch_assoc($query)) {
	 ?>
	<form method="post" action="proses_update.php?id=<?php echo $data['id']; ?>">
	
	 	<label>judul:</label><br>
		<input type="text" name="judul" value="<?php echo $data['judul']; ?>"><br>
		<label>isi</label><br>
		<input type="text" name="isi" value="<?php echo $data['isi']; ?>"><br>
		<?php } ?>
		<input type="submit" name="submit">
	</form>
</body>
</html>